# Abrir en ventana nueva (Mailspring)

Con la lista de mensajes sin panel de lectura, un clic sobre un mensaje lo abre
en una ventana aparte (la misma que se abre con doble clic).

- Ctrl/Cmd + clic o Shift + clic: selección múltiple, como siempre.
- Alt + clic: abre el mensaje en la misma ventana.
- Los clics en el check, la estrella/ícono de leído y los botones rápidos no cambian.
- Con panel de lectura activado, el plugin no hace nada.

## Instalación
1. Cerrá Mailspring.
2. Copiá la carpeta `mailspring-open-in-window` dentro de la carpeta `packages` de Mailspring.
3. Abrí Mailspring.

## Desinstalación
Cerrá Mailspring y borrá esa carpeta.
