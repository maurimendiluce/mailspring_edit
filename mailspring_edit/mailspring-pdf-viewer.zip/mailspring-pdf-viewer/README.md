# Visor de PDF en el mensaje (Mailspring)

Al tocar un adjunto PDF, el visor integrado de Mailspring (PDF.js) se despliega
dentro del propio mensaje, en el lugar del adjunto. Tiene botones para cerrarlo
y para abrir el PDF en la aplicación externa.

- Los adjuntos que no son PDF funcionan como siempre.
- Doble clic, menú contextual, descarga y quitar adjunto no cambian.
- Funciona en la ventana principal y en las ventanas de mensaje.
- Reemplaza el componente de adjuntos del núcleo mientras está activo y lo
  restaura al desactivarlo. No puede convivir con otro plugin que haga lo mismo
  (por ejemplo, el plugin `sample` de ejbiker93ss).

## Instalación
1. Cerrá Mailspring.
2. Si tenías instalada una versión anterior de `mailspring-pdf-viewer`, borrala.
3. Copiá la carpeta `mailspring-pdf-viewer` dentro de `%APPDATA%\Mailspring\packages`.
4. Abrí Mailspring.

## Desinstalación
Cerrá Mailspring y borrá esa carpeta.

## Si algo no anda
Abrí *Developer → Toggle Developer Tools*, tocá un PDF y mirá la consola por errores.
