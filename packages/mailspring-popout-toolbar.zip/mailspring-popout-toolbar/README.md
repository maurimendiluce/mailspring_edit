# Botones en la ventana del mensaje (Mailspring)

Agrega a la ventana emergente, debajo del asunto de un mensaje:

- **Eliminar** (mover a la papelera; cierra la ventana al terminar).
- **Mover a carpeta**.
- **Etiquetas** (solo en cuentas que usan etiquetas, como Gmail).

Los menús de carpetas y etiquetas son los del propio Mailspring. Solo actúa en
las ventanas de mensaje; la ventana principal no cambia.

## Instalación
1. Cerrá Mailspring.
2. Copiá la carpeta `mailspring-popout-toolbar` dentro de `%APPDATA%\Mailspring\packages`.
3. Abrí Mailspring y abrí un mensaje en una ventana aparte.

## Desinstalación
Cerrá Mailspring y borrá esa carpeta.

## Si algo no anda
Abrí *Developer → Toggle Developer Tools* en la ventana del mensaje y buscá en la
consola errores que empiecen con `[mailspring-popout-toolbar]`.
