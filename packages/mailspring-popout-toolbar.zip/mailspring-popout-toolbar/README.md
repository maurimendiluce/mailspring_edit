# Botones en la ventana del mensaje (Mailspring)

Agrega a la ventana emergente, debajo del asunto de un mensaje:

- **Eliminar** (mover a la papelera; cierra la ventana al terminar).
- **Marcar como no leído** (cierra la ventana al terminar).
- **Mover a carpeta** (cierra la ventana cuando el mensaje ya se movió).
- **Etiquetas** (solo en cuentas que usan etiquetas, como Gmail). Aplicar una
  etiqueta no cierra la ventana.

Si elegís la carpeta en la que el mensaje ya está, no hay nada que mover y la
ventana queda abierta. Si el movimiento no llega a completarse, la ventana
tampoco se cierra.

Los menús de carpetas y etiquetas son los del propio Mailspring, con su estilo
original (el plugin carga la hoja de estilos que Mailspring no carga en esta
ventana). Solo actúa en las ventanas de mensaje; la ventana principal no cambia.

## Instalación
1. Cerrá Mailspring por completo (también desde la bandeja del sistema).
2. Reemplazá la carpeta `mailspring-popout-toolbar` dentro de `%APPDATA%\Mailspring\packages`.
3. Abrí Mailspring y abrí un mensaje en una ventana aparte.

## Desinstalación
Cerrá Mailspring y borrá esa carpeta.

## Si algo no anda
Abrí *Developer → Toggle Developer Tools* en la ventana del mensaje y buscá en la
consola errores que empiecen con `[mailspring-popout-toolbar]`.
