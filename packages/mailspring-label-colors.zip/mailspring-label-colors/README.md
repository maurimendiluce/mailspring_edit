# Colores de etiquetas (Mailspring)

Permite elegir el color de cada etiqueta. Mailspring le asigna a cada una un
color calculado a partir de su nombre; este plugin lo reemplaza por el que vos
definas, y deja las demás etiquetas como están.

El color elegido se usa así: la etiqueta tiene un fondo claro y un texto oscuro
del mismo tono (como las de Mailspring), y el punto de color en los menús de
carpetas y etiquetas usa el color tal cual.

## Cómo se configura

La primera vez que se abre Mailspring con el plugin instalado, se crea el
archivo `label-colors.json` en la carpeta de datos de Mailspring:

- Windows: `%APPDATA%\Mailspring\label-colors.json`
- macOS: `~/Library/Application Support/Mailspring/label-colors.json`
- Linux: `~/.config/Mailspring/label-colors.json`

Editalo con el Bloc de notas. Cada línea es `"nombre de la etiqueta": "#color"`:

```json
{
  "Trabajo": "#e53935",
  "Personal": "#43a047",
  "Facturas": "#fb8c00"
}
```

- El nombre tiene que ser el que Mailspring muestra, sin importar mayúsculas.
  Para una sub-etiqueta, el nombre completo con la barra: `"Trabajo/Proyecto"`.
- El color va en formato `#rrggbb` (o `#rgb`). Para elegirlo podés buscar
  "selector de color" en internet y copiar el código hexadecimal.
- Las líneas cuyo nombre empieza con `_` se ignoran (sirven de comentario).
- Cuidado con las comas: todas las líneas llevan coma al final, menos la última.

Para ver los cambios, cerrá Mailspring por completo y abrilo de nuevo.
Si el archivo tiene un error, Mailspring avisa y se usan los colores originales.

## Instalación
1. Cerrá Mailspring por completo (también desde la bandeja del sistema).
2. Copiá la carpeta `mailspring-label-colors` dentro de `%APPDATA%\Mailspring\packages`.
3. Abrí Mailspring, cerralo y editá `label-colors.json`. Después abrilo de nuevo.

## Notas
- El color solo cambia cómo se ve en este Mailspring: no se envía a Gmail ni a
  otros programas de correo.
- Funciona en la ventana principal y en las ventanas de mensaje.
- Si usás un tema que cambia el estilo de las etiquetas, puede modificar el
  aspecto (sombras, bordes), pero no el color elegido.

## Desinstalación
Cerrá Mailspring y borrá la carpeta del plugin. El archivo `label-colors.json`
queda en la carpeta de datos; podés borrarlo también.

## Si algo no anda
Abrí *Developer → Toggle Developer Tools* y buscá en la consola líneas que
empiecen con `[mailspring-label-colors]`: indican cuántas etiquetas se
cargaron y qué entradas no se pudieron leer.
